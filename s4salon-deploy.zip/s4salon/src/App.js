import { useState, useEffect } from "react";

// ─── DATA STORE ────────────────────────────────────────────────────────────────
const USERS = {
  owner: { password: "owner123", role: "owner", name: "Owner" },
  staff: { password: "staff123", role: "staff", name: "Staff" },
  customer: { password: "cust123", role: "customer", name: "Customer" },
};

const INITIAL_SERVICES = [
  { id: 1, name: "Haircut", price: 250, duration: "30 min", category: "Hair" },
  { id: 2, name: "Hair Color", price: 750, duration: "90 min", category: "Hair" },
  { id: 3, name: "Blowout", price: 400, duration: "45 min", category: "Hair" },
  { id: 4, name: "Facial", price: 600, duration: "60 min", category: "Skin" },
  { id: 5, name: "Manicure", price: 300, duration: "30 min", category: "Nails" },
  { id: 6, name: "Pedicure", price: 450, duration: "45 min", category: "Nails" },
];

const INITIAL_PRODUCTS = [
  { id: 1, name: "Shampoo Pro", price: 180, stock: 24, category: "Hair Care" },
  { id: 2, name: "Conditioner Silk", price: 200, stock: 18, category: "Hair Care" },
  { id: 3, name: "Face Serum", price: 350, stock: 10, category: "Skin Care" },
  { id: 4, name: "Nail Polish Set", price: 220, stock: 15, category: "Nails" },
];

const INITIAL_APPOINTMENTS = [
  { id: 1, customer: "Ravi Kumar", service: "Haircut", date: "2026-04-27", time: "10:00", staff: "Priya", status: "confirmed", price: 250 },
  { id: 2, customer: "Anita S.", service: "Facial", date: "2026-04-27", time: "14:00", staff: "Priya", status: "confirmed", price: 600 },
  { id: 3, customer: "Meena R.", service: "Manicure", date: "2026-04-28", time: "11:30", staff: "Priya", status: "pending", price: 300 },
];

const INITIAL_SALES = [
  { id: 1, date: "2026-04-24", customer: "Ravi Kumar", items: "Haircut, Shampoo Pro", total: 430, paid: true, method: "QR" },
  { id: 2, date: "2026-04-25", customer: "Sunita D.", items: "Hair Color", total: 750, paid: true, method: "Cash" },
  { id: 3, date: "2026-04-26", customer: "Anita S.", items: "Facial, Face Serum", total: 950, paid: false, method: "-" },
];

// ─── STYLES ────────────────────────────────────────────────────────────────────
const S = {
  app: {
    fontFamily: "'Georgia', 'Times New Roman', serif",
    background: "#0d0d0d",
    minHeight: "100vh",
    color: "#f5efe6",
    maxWidth: 420,
    margin: "0 auto",
    position: "relative",
  },
  loginWrap: {
    minHeight: "100vh",
    background: "linear-gradient(160deg, #1a0a00 0%, #0d0d0d 50%, #0a0a1a 100%)",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
  },
  logoMark: {
    width: 88, height: 88, borderRadius: "50%",
    background: "linear-gradient(135deg, #c9a96e 0%, #8b5e34 100%)",
    display: "flex", alignItems: "center", justifyContent: "center",
    fontSize: 38, marginBottom: 14,
    boxShadow: "0 0 48px rgba(201,169,110,0.45)",
  },
  brandName: {
    fontFamily: "'Georgia', serif",
    fontSize: 38, fontWeight: "bold",
    letterSpacing: 6, color: "#c9a96e", marginBottom: 2,
  },
  brandSub: { fontSize: 12, color: "#8a7a6a", letterSpacing: 5, marginBottom: 36 },
  roleCards: { display: "flex", flexDirection: "column", gap: 12, width: "100%" },
  roleCard: (active) => ({
    background: active ? "rgba(201,169,110,0.15)" : "rgba(255,255,255,0.04)",
    border: `1px solid ${active ? "#c9a96e" : "rgba(255,255,255,0.08)"}`,
    borderRadius: 14, padding: "14px 18px",
    cursor: "pointer", transition: "all 0.25s",
    display: "flex", alignItems: "center", gap: 14,
  }),
  roleIcon: {
    fontSize: 26, width: 46, height: 46,
    display: "flex", alignItems: "center", justifyContent: "center",
    background: "rgba(201,169,110,0.1)", borderRadius: 10,
  },
  roleTitle: { fontWeight: "bold", fontSize: 15, color: "#f5efe6" },
  roleDesc: { fontSize: 11, color: "#8a7a6a", marginTop: 2 },
  inputWrap: { marginTop: 22, width: "100%" },
  input: {
    width: "100%", padding: "14px 16px", borderRadius: 12,
    background: "rgba(255,255,255,0.06)", border: "1px solid rgba(201,169,110,0.2)",
    color: "#f5efe6", fontSize: 15, outline: "none",
    boxSizing: "border-box", marginBottom: 12, fontFamily: "Georgia, serif",
  },
  loginBtn: {
    width: "100%", padding: "15px", borderRadius: 12,
    background: "linear-gradient(135deg, #c9a96e, #8b5e34)",
    color: "#fff", fontWeight: "bold", fontSize: 16,
    border: "none", cursor: "pointer", letterSpacing: 1,
    boxShadow: "0 4px 20px rgba(201,169,110,0.3)",
    fontFamily: "Georgia, serif",
  },
  header: {
    background: "rgba(13,13,13,0.97)",
    borderBottom: "1px solid rgba(201,169,110,0.15)",
    padding: "14px 18px",
    display: "flex", alignItems: "center", justifyContent: "space-between",
    position: "sticky", top: 0, zIndex: 100,
    backdropFilter: "blur(10px)",
  },
  headerTitle: { fontSize: 20, fontWeight: "bold", color: "#c9a96e", letterSpacing: 2 },
  headerSub: { fontSize: 11, color: "#8a7a6a", marginTop: 1 },
  navBar: {
    position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)",
    width: "100%", maxWidth: 420,
    background: "rgba(13,13,13,0.97)",
    borderTop: "1px solid rgba(201,169,110,0.15)",
    display: "flex", justifyContent: "space-around",
    padding: "10px 0 18px", zIndex: 100,
    backdropFilter: "blur(10px)",
  },
  navItem: (active) => ({
    display: "flex", flexDirection: "column", alignItems: "center",
    gap: 3, cursor: "pointer", padding: "4px 14px",
    color: active ? "#c9a96e" : "#4a4a4a", transition: "color 0.2s",
  }),
  page: { padding: "16px 16px 96px" },
  card: {
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(201,169,110,0.1)",
    borderRadius: 16, padding: 16, marginBottom: 12,
  },
  cardGold: {
    background: "linear-gradient(135deg, rgba(201,169,110,0.12), rgba(139,94,52,0.08))",
    border: "1px solid rgba(201,169,110,0.25)",
    borderRadius: 16, padding: 16, marginBottom: 12,
  },
  row: { display: "flex", alignItems: "center", justifyContent: "space-between" },
  badge: (color) => ({
    fontSize: 10, padding: "3px 9px", borderRadius: 20,
    background: color === "green" ? "rgba(100,200,100,0.15)"
      : color === "gold" ? "rgba(201,169,110,0.2)"
      : "rgba(255,100,100,0.15)",
    color: color === "green" ? "#6dc76d" : color === "gold" ? "#c9a96e" : "#e07070",
    fontWeight: "bold", letterSpacing: 0.5,
  }),
  sectionTitle: {
    fontSize: 11, fontWeight: "bold", color: "#8a7a6a",
    textTransform: "uppercase", letterSpacing: 2,
    marginBottom: 10, marginTop: 18,
  },
  btn: (variant = "primary") => ({
    padding: "10px 18px", borderRadius: 10, border: "none",
    background: variant === "primary" ? "linear-gradient(135deg, #c9a96e, #8b5e34)"
      : variant === "ghost" ? "rgba(255,255,255,0.06)"
      : variant === "danger" ? "rgba(255,80,80,0.15)"
      : "rgba(201,169,110,0.12)",
    color: variant === "primary" ? "#fff" : variant === "danger" ? "#e07070" : "#c9a96e",
    fontSize: 13, fontWeight: "bold", cursor: "pointer",
    border: variant !== "primary" ? "1px solid rgba(201,169,110,0.2)" : "none",
    fontFamily: "Georgia, serif",
  }),
  modal: {
    position: "fixed", inset: 0, background: "rgba(0,0,0,0.88)",
    display: "flex", alignItems: "flex-end", justifyContent: "center",
    zIndex: 200, backdropFilter: "blur(5px)",
  },
  modalSheet: {
    background: "#131313", borderRadius: "22px 22px 0 0",
    padding: 24, width: "100%", maxWidth: 420,
    border: "1px solid rgba(201,169,110,0.15)",
    maxHeight: "88vh", overflowY: "auto",
  },
  divider: { height: 1, background: "rgba(201,169,110,0.1)", margin: "14px 0" },
  textMuted: { fontSize: 13, color: "#8a7a6a" },
  tag: {
    fontSize: 11, padding: "4px 10px", borderRadius: 20,
    background: "rgba(201,169,110,0.1)", color: "#c9a96e",
    display: "inline-block", marginRight: 6, marginBottom: 4,
  },
};

// ─── QR PAYMENT MODAL ──────────────────────────────────────────────────────────
function QRModal({ amount, onClose, onPaid }) {
  const [paid, setPaid] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setPaid(true), 5000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={S.modal} onClick={onClose}>
      <div style={S.modalSheet} onClick={e => e.stopPropagation()}>
        <div style={{ ...S.row, marginBottom: 16 }}>
          <span style={{ fontWeight: "bold", fontSize: 18, color: "#c9a96e" }}>Collect Payment</span>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#8a7a6a", fontSize: 22, cursor: "pointer" }}>✕</button>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 30, fontWeight: "bold", color: "#c9a96e", marginBottom: 4 }}>₹{amount}</div>
          <div style={S.textMuted}>Scan QR code to pay</div>
          <div style={{
            margin: "20px auto", width: 200, height: 200, background: "#fff",
            borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center",
            position: "relative", overflow: "hidden",
            boxShadow: "0 0 40px rgba(201,169,110,0.2)",
          }}>
            <svg width="170" height="170" viewBox="0 0 170 170">
              <rect width="170" height="170" fill="white" />
              {[0,1,2,3,4,5,6,7].map(i => [0,1,2,3,4,5,6,7].map(j => {
                const skip = (i < 3 && j < 3) || (i > 4 && j < 3) || (i < 3 && j > 4);
                return (!skip && ((i + j * 3 + i * j) % 2 === 0))
                  ? <rect key={`${i}-${j}`} x={i * 21 + 1} y={j * 21 + 1} width="19" height="19" fill="#111" rx="2" />
                  : null;
              }))}
              <rect x="8" y="8" width="54" height="54" fill="none" stroke="#111" strokeWidth="5" rx="5" />
              <rect x="18" y="18" width="34" height="34" fill="#111" rx="3" />
              <rect x="108" y="8" width="54" height="54" fill="none" stroke="#111" strokeWidth="5" rx="5" />
              <rect x="118" y="18" width="34" height="34" fill="#111" rx="3" />
              <rect x="8" y="108" width="54" height="54" fill="none" stroke="#111" strokeWidth="5" rx="5" />
              <rect x="18" y="118" width="34" height="34" fill="#111" rx="3" />
              <text x="85" y="90" textAnchor="middle" fontSize="11" fill="#8b5e34" fontWeight="bold" fontFamily="Georgia">S4</text>
            </svg>
            {paid && (
              <div style={{
                position: "absolute", inset: 0, background: "rgba(30,90,30,0.97)",
                display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", borderRadius: 16,
              }}>
                <div style={{ fontSize: 52 }}>✅</div>
                <div style={{ fontWeight: "bold", color: "#aaffaa", marginTop: 8, fontSize: 16 }}>Payment Received!</div>
              </div>
            )}
          </div>
          {!paid
            ? <div style={{ ...S.textMuted, fontSize: 12 }}>⏳ Waiting for payment… (demo: confirms in 5s)</div>
            : <button style={{ ...S.btn("primary"), width: "100%", padding: "14px", marginTop: 12, fontSize: 15 }} onClick={onPaid}>
                ✅ Confirm & Generate Receipt
              </button>
          }
          <div style={S.divider} />
          <div>
            {["UPI", "PhonePe", "Google Pay", "Paytm", "BHIM"].map(p => (
              <span key={p} style={S.tag}>{p}</span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── BILL MODAL ────────────────────────────────────────────────────────────────
function BillModal({ bill, onClose, onQR }) {
  const gst = Math.round(bill.total * 0.18);
  const grand = bill.total + gst;
  return (
    <div style={S.modal}>
      <div style={S.modalSheet}>
        <div style={{ ...S.row, marginBottom: 16 }}>
          <span style={{ fontWeight: "bold", fontSize: 18, color: "#c9a96e" }}>Bill #{bill.id}</span>
          <button onClick={onClose} style={{ background: "none", border: "none", color: "#8a7a6a", fontSize: 22, cursor: "pointer" }}>✕</button>
        </div>
        <div style={{ background: "rgba(201,169,110,0.05)", borderRadius: 14, padding: 16, border: "1px solid rgba(201,169,110,0.1)" }}>
          <div style={{ textAlign: "center", marginBottom: 12 }}>
            <div style={{ fontSize: 22, letterSpacing: 4, color: "#c9a96e", fontWeight: "bold" }}>✂ S4 SALON</div>
            <div style={{ fontSize: 11, color: "#8a7a6a" }}>Premium Hair & Beauty Studio</div>
          </div>
          <div style={S.divider} />
          <div style={{ ...S.row, marginBottom: 8 }}>
            <span style={S.textMuted}>Customer</span>
            <span style={{ fontWeight: "bold" }}>{bill.customer}</span>
          </div>
          <div style={{ ...S.row, marginBottom: 8 }}>
            <span style={S.textMuted}>Date</span>
            <span>{bill.date}</span>
          </div>
          <div style={{ ...S.row, marginBottom: 8 }}>
            <span style={S.textMuted}>Bill No.</span>
            <span>#{bill.id}</span>
          </div>
          <div style={S.divider} />
          {bill.items.map((item, i) => (
            <div key={i} style={{ ...S.row, marginBottom: 10 }}>
              <span style={{ fontSize: 14 }}>{item.name}</span>
              <span style={{ color: "#c9a96e", fontWeight: "bold" }}>₹{item.price}</span>
            </div>
          ))}
          <div style={S.divider} />
          <div style={{ ...S.row, marginBottom: 6 }}>
            <span style={S.textMuted}>Subtotal</span>
            <span>₹{bill.total}</span>
          </div>
          <div style={{ ...S.row, marginBottom: 6 }}>
            <span style={S.textMuted}>GST (18%)</span>
            <span>₹{gst}</span>
          </div>
          <div style={{ ...S.row, fontSize: 18, fontWeight: "bold", marginTop: 8 }}>
            <span>Grand Total</span>
            <span style={{ color: "#c9a96e" }}>₹{grand}</span>
          </div>
        </div>
        <button onClick={() => onQR(grand)} style={{ ...S.btn("primary"), width: "100%", padding: "14px", marginTop: 14, fontSize: 15 }}>
          📱 Pay via QR Code
        </button>
        <button onClick={onClose} style={{ ...S.btn("ghost"), width: "100%", padding: "12px", marginTop: 8, fontSize: 13 }}>
          💵 Cash Payment
        </button>
      </div>
    </div>
  );
}

// ─── STAFF PORTAL ──────────────────────────────────────────────────────────────
function StaffPortal() {
  const [tab, setTab] = useState("billing");
  const [services] = useState(INITIAL_SERVICES);
  const [appointments] = useState(INITIAL_APPOINTMENTS);
  const [selected, setSelected] = useState([]);
  const [customer, setCustomer] = useState("");
  const [showBill, setShowBill] = useState(null);
  const [showQR, setShowQR] = useState(false);
  const [qrAmount, setQrAmount] = useState(0);
  const [success, setSuccess] = useState(false);

  const total = selected.reduce((s, id) => s + (services.find(x => x.id === id)?.price || 0), 0);
  const toggle = (id) => setSelected(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  const generateBill = () => {
    if (!customer.trim() || selected.length === 0) return;
    setShowBill({
      id: Math.floor(Math.random() * 9000) + 1000,
      customer,
      date: new Date().toLocaleDateString("en-IN"),
      items: selected.map(id => services.find(x => x.id === id)).map(s => ({ name: s.name, price: s.price })),
      total,
    });
  };

  const today = appointments.filter(a => a.date === "2026-04-27");

  return (
    <>
      <div style={S.header}>
        <div>
          <div style={S.headerTitle}>S4 SALON</div>
          <div style={S.headerSub}>Staff Portal · Priya</div>
        </div>
        <span style={S.badge("gold")}>{today.length} Today</span>
      </div>

      <div style={S.page}>
        {tab === "billing" && (
          <>
            {success && (
              <div style={{ ...S.cardGold, textAlign: "center", padding: 20 }}>
                <div style={{ fontSize: 36 }}>🎉</div>
                <div style={{ fontWeight: "bold", color: "#c9a96e", fontSize: 16 }}>Payment Successful!</div>
                <div style={{ ...S.textMuted, fontSize: 12, marginTop: 4 }}>Receipt sent to customer</div>
                <button onClick={() => { setSuccess(false); setSelected([]); setCustomer(""); }} style={{ ...S.btn("gold"), marginTop: 12 }}>New Bill</button>
              </div>
            )}
            {!success && (
              <>
                <p style={S.sectionTitle}>Customer Name</p>
                <input
                  style={{ ...S.input, marginBottom: 4 }}
                  placeholder="Enter customer name…"
                  value={customer}
                  onChange={e => setCustomer(e.target.value)}
                />
                <p style={S.sectionTitle}>Select Services</p>
                {["Hair", "Skin", "Nails"].map(cat => (
                  <div key={cat}>
                    <div style={{ fontSize: 11, color: "#8a7a6a", textTransform: "uppercase", letterSpacing: 1, marginTop: 10, marginBottom: 6 }}>{cat}</div>
                    {services.filter(s => s.category === cat).map(s => (
                      <div key={s.id} onClick={() => toggle(s.id)} style={{
                        ...S.card,
                        border: selected.includes(s.id) ? "1px solid #c9a96e" : "1px solid rgba(201,169,110,0.08)",
                        background: selected.includes(s.id) ? "rgba(201,169,110,0.1)" : "rgba(255,255,255,0.03)",
                        cursor: "pointer", marginBottom: 8,
                        display: "flex", justifyContent: "space-between", alignItems: "center",
                      }}>
                        <div>
                          <div style={{ fontWeight: "bold", fontSize: 14 }}>{s.name}</div>
                          <div style={{ fontSize: 12, color: "#8a7a6a" }}>⏱ {s.duration}</div>
                        </div>
                        <div style={{ textAlign: "right" }}>
                          <div style={{ color: "#c9a96e", fontWeight: "bold" }}>₹{s.price}</div>
                          {selected.includes(s.id) && <div style={{ fontSize: 18 }}>✅</div>}
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
                {selected.length > 0 && (
                  <div style={{ ...S.cardGold, marginTop: 8 }}>
                    <div style={{ ...S.row, marginBottom: 10 }}>
                      <span style={{ fontSize: 14 }}>{selected.length} service(s) selected</span>
                      <span style={{ fontSize: 22, fontWeight: "bold", color: "#c9a96e" }}>₹{total}</span>
                    </div>
                    <button
                      onClick={generateBill}
                      disabled={!customer.trim()}
                      style={{ ...S.btn("primary"), width: "100%", padding: "13px", opacity: customer.trim() ? 1 : 0.5 }}
                    >
                      🧾 Generate Bill
                    </button>
                  </div>
                )}
              </>
            )}
          </>
        )}

        {tab === "appointments" && (
          <>
            <p style={S.sectionTitle}>Today's Appointments</p>
            {today.length === 0 && <div style={S.textMuted}>No appointments today.</div>}
            {today.map(a => (
              <div key={a.id} style={S.card}>
                <div style={S.row}>
                  <div>
                    <div style={{ fontWeight: "bold", fontSize: 15 }}>{a.customer}</div>
                    <div style={{ color: "#8a7a6a", fontSize: 12 }}>{a.service} · {a.time}</div>
                  </div>
                  <span style={S.badge(a.status === "confirmed" ? "green" : "gold")}>{a.status}</span>
                </div>
              </div>
            ))}
            <p style={S.sectionTitle}>Upcoming</p>
            {appointments.filter(a => a.date !== "2026-04-27").map(a => (
              <div key={a.id} style={S.card}>
                <div style={S.row}>
                  <div>
                    <div style={{ fontWeight: "bold" }}>{a.customer}</div>
                    <div style={{ color: "#8a7a6a", fontSize: 12 }}>{a.service} · {a.date} {a.time}</div>
                  </div>
                  <span style={S.badge("gold")}>{a.status}</span>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      <div style={S.navBar}>
        {[{ id: "billing", icon: "🧾", label: "Billing" }, { id: "appointments", icon: "📅", label: "Schedule" }].map(n => (
          <div key={n.id} style={S.navItem(tab === n.id)} onClick={() => setTab(n.id)}>
            <span style={{ fontSize: 24 }}>{n.icon}</span>
            <span style={{ fontSize: 10, color: tab === n.id ? "#c9a96e" : "#4a4a4a" }}>{n.label}</span>
          </div>
        ))}
      </div>

      {showBill && (
        <BillModal
          bill={showBill}
          onClose={() => setShowBill(null)}
          onQR={(amt) => { setQrAmount(amt); setShowBill(null); setShowQR(true); }}
        />
      )}
      {showQR && (
        <QRModal
          amount={qrAmount}
          onClose={() => setShowQR(false)}
          onPaid={() => { setShowQR(false); setSuccess(true); }}
        />
      )}
    </>
  );
}

// ─── CUSTOMER PORTAL ───────────────────────────────────────────────────────────
function CustomerPortal({ onLogout }) {
  const [tab, setTab] = useState("home");
  const [services] = useState(INITIAL_SERVICES);
  const [selected, setSelected] = useState([]);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [booked, setBooked] = useState(false);
  const [myAppts] = useState(INITIAL_APPOINTMENTS.filter(a => a.customer === "Ravi Kumar"));

  const total = selected.reduce((s, id) => s + (services.find(x => x.id === id)?.price || 0), 0);
  const toggle = (id) => setSelected(p => p.includes(id) ? p.filter(x => x !== id) : [...p, id]);

  return (
    <>
      <div style={S.header}>
        <div>
          <div style={S.headerTitle}>S4 SALON</div>
          <div style={S.headerSub}>Welcome 👋</div>
        </div>
        <span style={{ fontSize: 22 }}>🔔</span>
      </div>

      <div style={S.page}>
        {tab === "home" && (
          <>
            <div style={{ ...S.cardGold, textAlign: "center", padding: "24px 16px" }}>
              <div style={{ fontSize: 40, marginBottom: 8 }}>✂</div>
              <div style={{ fontWeight: "bold", fontSize: 20, color: "#c9a96e", letterSpacing: 2 }}>S4 SALON</div>
              <div style={{ color: "#8a7a6a", fontSize: 13, margin: "8px 0 18px" }}>Premium Hair & Beauty Studio</div>
              <button onClick={() => setTab("book")} style={{ ...S.btn("primary"), padding: "13px 36px", fontSize: 15 }}>
                📅 Book Appointment
              </button>
            </div>

            <p style={S.sectionTitle}>Our Services</p>
            {services.map(s => (
              <div key={s.id} style={{ ...S.card, display: "flex", alignItems: "center", gap: 14 }}>
                <div style={{ fontSize: 26 }}>
                  {s.category === "Hair" ? "💇" : s.category === "Skin" ? "✨" : "💅"}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: "bold", fontSize: 14 }}>{s.name}</div>
                  <div style={{ color: "#8a7a6a", fontSize: 12 }}>{s.duration}</div>
                </div>
                <div style={{ color: "#c9a96e", fontWeight: "bold" }}>₹{s.price}</div>
              </div>
            ))}
          </>
        )}

        {tab === "book" && (
          <>
            <p style={S.sectionTitle}>Choose Services</p>
            {services.map(s => (
              <div key={s.id} onClick={() => toggle(s.id)} style={{
                ...S.card, cursor: "pointer", marginBottom: 8,
                border: selected.includes(s.id) ? "1px solid #c9a96e" : "1px solid rgba(201,169,110,0.08)",
                background: selected.includes(s.id) ? "rgba(201,169,110,0.1)" : "rgba(255,255,255,0.03)",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <div>
                  <div style={{ fontWeight: "bold", fontSize: 14 }}>{s.name}</div>
                  <div style={{ color: "#8a7a6a", fontSize: 12 }}>⏱ {s.duration}</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ color: "#c9a96e", fontWeight: "bold" }}>₹{s.price}</div>
                  {selected.includes(s.id) && <div>✅</div>}
                </div>
              </div>
            ))}

            <p style={S.sectionTitle}>Pick Date & Time</p>
            <input type="date" style={S.input} value={date} onChange={e => setDate(e.target.value)} />
            <select style={{ ...S.input, background: "rgba(255,255,255,0.06)" }} value={time} onChange={e => setTime(e.target.value)}>
              <option value="">Select Time Slot</option>
              {["09:00 AM", "10:00 AM", "11:00 AM", "01:00 PM", "02:00 PM", "03:00 PM", "04:00 PM", "05:00 PM"].map(t => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>

            {selected.length > 0 && date && time && !booked && (
              <div style={S.cardGold}>
                <div style={{ ...S.row, marginBottom: 6 }}>
                  <span style={{ fontSize: 13 }}>{selected.length} service(s)</span>
                  <span style={{ fontWeight: "bold", color: "#c9a96e", fontSize: 20 }}>₹{total}</span>
                </div>
                <div style={{ ...S.textMuted, fontSize: 12, marginBottom: 12 }}>{date} · {time}</div>
                <button onClick={() => setBooked(true)} style={{ ...S.btn("primary"), width: "100%", padding: "13px" }}>
                  ✅ Confirm Booking
                </button>
              </div>
            )}

            {booked && (
              <div style={{ ...S.cardGold, textAlign: "center", padding: 24 }}>
                <div style={{ fontSize: 44, marginBottom: 8 }}>🎉</div>
                <div style={{ fontWeight: "bold", fontSize: 16, color: "#c9a96e" }}>Appointment Confirmed!</div>
                <div style={{ color: "#8a7a6a", fontSize: 13, marginTop: 6 }}>{date} at {time}</div>
                <div style={{ color: "#8a7a6a", fontSize: 12, marginTop: 4 }}>S4 Salon will see you soon 💇</div>
                <button onClick={() => { setBooked(false); setSelected([]); setDate(""); setTime(""); }} style={{ ...S.btn("gold"), marginTop: 16 }}>
                  Book Another
                </button>
              </div>
            )}
          </>
        )}

        {tab === "visits" && (
          <>
            <p style={S.sectionTitle}>My Appointments</p>
            {myAppts.length === 0 && <div style={S.textMuted}>No appointments yet.</div>}
            {myAppts.map(a => (
              <div key={a.id} style={S.card}>
                <div style={S.row}>
                  <div>
                    <div style={{ fontWeight: "bold", fontSize: 15 }}>{a.service}</div>
                    <div style={{ color: "#8a7a6a", fontSize: 12 }}>{a.date} · {a.time}</div>
                    <div style={{ color: "#8a7a6a", fontSize: 12 }}>Staff: {a.staff}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <span style={S.badge(a.status === "confirmed" ? "green" : "gold")}>{a.status}</span>
                    <div style={{ color: "#c9a96e", fontWeight: "bold", marginTop: 6 }}>₹{a.price}</div>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      <div style={S.navBar}>
        {[
          { id: "home", icon: "🏠", label: "Home" },
          { id: "book", icon: "📅", label: "Book" },
          { id: "visits", icon: "🧾", label: "My Visits" },
        ].map(n => (
          <div key={n.id} style={S.navItem(tab === n.id)} onClick={() => setTab(n.id)}>
            <span style={{ fontSize: 24 }}>{n.icon}</span>
            <span style={{ fontSize: 10, color: tab === n.id ? "#c9a96e" : "#4a4a4a" }}>{n.label}</span>
          </div>
        ))}
      </div>
    </>
  );
}

// ─── OWNER PORTAL ──────────────────────────────────────────────────────────────
function OwnerPortal() {
  const [tab, setTab] = useState("dashboard");
  const [services, setServices] = useState(INITIAL_SERVICES);
  const [products, setProducts] = useState(INITIAL_PRODUCTS);
  const [sales] = useState(INITIAL_SALES);
  const [editItem, setEditItem] = useState(null);
  const [addMode, setAddMode] = useState(null);
  const [form, setForm] = useState({});

  const totalRevenue = sales.filter(s => s.paid).reduce((sum, s) => sum + s.total, 0);
  const pending = sales.filter(s => !s.paid).reduce((sum, s) => sum + s.total, 0);

  const saveService = () => {
    if (editItem) {
      setServices(p => p.map(s => s.id === editItem.id ? { ...s, ...form, price: Number(form.price) } : s));
    } else {
      setServices(p => [...p, { id: Date.now(), name: form.name, price: Number(form.price), duration: form.duration || "30 min", category: form.category || "Hair" }]);
    }
    setEditItem(null); setAddMode(null); setForm({});
  };

  const saveProduct = () => {
    if (editItem) {
      setProducts(p => p.map(s => s.id === editItem.id ? { ...s, ...form, price: Number(form.price), stock: Number(form.stock) } : s));
    } else {
      setProducts(p => [...p, { id: Date.now(), name: form.name, price: Number(form.price), stock: Number(form.stock || 0), category: form.category || "Hair Care" }]);
    }
    setEditItem(null); setAddMode(null); setForm({});
  };

  return (
    <>
      <div style={S.header}>
        <div>
          <div style={S.headerTitle}>S4 SALON</div>
          <div style={S.headerSub}>Owner Dashboard</div>
        </div>
        <span style={S.badge("gold")}>OWNER</span>
      </div>

      <div style={S.page}>
        {tab === "dashboard" && (
          <>
            <p style={S.sectionTitle}>Overview</p>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 4 }}>
              {[
                { label: "Revenue", value: `₹${totalRevenue.toLocaleString("en-IN")}`, icon: "💰" },
                { label: "Pending", value: `₹${pending.toLocaleString("en-IN")}`, icon: "⏳" },
                { label: "Appointments", value: INITIAL_APPOINTMENTS.length, icon: "📅" },
                { label: "Services", value: services.length, icon: "💇" },
              ].map(m => (
                <div key={m.label} style={S.cardGold}>
                  <div style={{ fontSize: 26, marginBottom: 6 }}>{m.icon}</div>
                  <div style={{ fontSize: 10, color: "#8a7a6a", textTransform: "uppercase", letterSpacing: 1 }}>{m.label}</div>
                  <div style={{ fontSize: 20, fontWeight: "bold", color: "#c9a96e" }}>{m.value}</div>
                </div>
              ))}
            </div>

            <p style={S.sectionTitle}>Recent Transactions</p>
            {sales.map(s => (
              <div key={s.id} style={S.card}>
                <div style={S.row}>
                  <div>
                    <div style={{ fontWeight: "bold", fontSize: 14 }}>{s.customer}</div>
                    <div style={{ fontSize: 12, color: "#8a7a6a" }}>{s.items}</div>
                    <div style={{ fontSize: 11, color: "#8a7a6a" }}>{s.date} · {s.method}</div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <div style={{ fontWeight: "bold", color: "#c9a96e", fontSize: 15 }}>₹{s.total}</div>
                    <span style={S.badge(s.paid ? "green" : "red")}>{s.paid ? "Paid" : "Pending"}</span>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}

        {tab === "services" && (
          <>
            <div style={{ ...S.row, marginBottom: 4 }}>
              <p style={{ ...S.sectionTitle, margin: 0 }}>Services ({services.length})</p>
              <button onClick={() => { setAddMode("service"); setEditItem(null); setForm({}); }} style={S.btn("gold")}>+ Add</button>
            </div>
            {services.map(s => (
              <div key={s.id} style={S.card}>
                <div style={S.row}>
                  <div>
                    <div style={{ fontWeight: "bold", fontSize: 14 }}>{s.name}</div>
                    <div style={{ fontSize: 12, color: "#8a7a6a" }}>{s.category} · {s.duration}</div>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontWeight: "bold", color: "#c9a96e" }}>₹{s.price}</span>
                    <button onClick={() => { setEditItem(s); setForm({ ...s }); setAddMode("service"); }} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18 }}>✏️</button>
                    <button onClick={() => setServices(p => p.filter(x => x.id !== s.id))} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18 }}>🗑️</button>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}

        {tab === "products" && (
          <>
            <div style={{ ...S.row, marginBottom: 4 }}>
              <p style={{ ...S.sectionTitle, margin: 0 }}>Products ({products.length})</p>
              <button onClick={() => { setAddMode("product"); setEditItem(null); setForm({}); }} style={S.btn("gold")}>+ Add</button>
            </div>
            {products.map(p => (
              <div key={p.id} style={S.card}>
                <div style={S.row}>
                  <div>
                    <div style={{ fontWeight: "bold", fontSize: 14 }}>{p.name}</div>
                    <div style={{ fontSize: 12, color: "#8a7a6a" }}>{p.category}</div>
                    <span style={{ ...S.badge(p.stock < 12 ? "red" : "green"), marginTop: 4, display: "inline-block" }}>
                      Stock: {p.stock}
                    </span>
                  </div>
                  <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                    <span style={{ fontWeight: "bold", color: "#c9a96e" }}>₹{p.price}</span>
                    <button onClick={() => { setEditItem(p); setForm({ ...p }); setAddMode("product"); }} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18 }}>✏️</button>
                    <button onClick={() => setProducts(prev => prev.filter(x => x.id !== p.id))} style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18 }}>🗑️</button>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>

      {addMode && (
        <div style={S.modal}>
          <div style={S.modalSheet}>
            <div style={{ ...S.row, marginBottom: 16 }}>
              <span style={{ fontWeight: "bold", fontSize: 17, color: "#c9a96e" }}>
                {editItem ? "Edit" : "Add"} {addMode === "service" ? "Service" : "Product"}
              </span>
              <button onClick={() => { setAddMode(null); setEditItem(null); setForm({}); }} style={{ background: "none", border: "none", color: "#8a7a6a", fontSize: 22, cursor: "pointer" }}>✕</button>
            </div>
            <input style={S.input} placeholder="Name" value={form.name || ""} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            <input style={S.input} placeholder="Price (₹)" type="number" value={form.price || ""} onChange={e => setForm(f => ({ ...f, price: e.target.value }))} />
            {addMode === "service" && (
              <input style={S.input} placeholder="Duration (e.g. 30 min)" value={form.duration || ""} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))} />
            )}
            {addMode === "product" && (
              <input style={S.input} placeholder="Stock quantity" type="number" value={form.stock || ""} onChange={e => setForm(f => ({ ...f, stock: e.target.value }))} />
            )}
            <select style={{ ...S.input, background: "rgba(255,255,255,0.06)" }} value={form.category || ""} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              <option value="">Select Category</option>
              {addMode === "service"
                ? ["Hair", "Skin", "Nails"].map(c => <option key={c} value={c}>{c}</option>)
                : ["Hair Care", "Skin Care", "Nails", "Other"].map(c => <option key={c} value={c}>{c}</option>)
              }
            </select>
            <button onClick={addMode === "service" ? saveService : saveProduct} style={{ ...S.btn("primary"), width: "100%", padding: "13px", marginTop: 8 }}>
              💾 Save
            </button>
          </div>
        </div>
      )}

      <div style={S.navBar}>
        {[
          { id: "dashboard", icon: "📊", label: "Dashboard" },
          { id: "services", icon: "💇", label: "Services" },
          { id: "products", icon: "📦", label: "Products" },
        ].map(n => (
          <div key={n.id} style={S.navItem(tab === n.id)} onClick={() => setTab(n.id)}>
            <span style={{ fontSize: 24 }}>{n.icon}</span>
            <span style={{ fontSize: 10, color: tab === n.id ? "#c9a96e" : "#4a4a4a" }}>{n.label}</span>
          </div>
        ))}
      </div>
    </>
  );
}

// ─── LOGIN ─────────────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }) {
  const [role, setRole] = useState(null);
  const [pass, setPass] = useState("");
  const [error, setError] = useState("");
  const [showPass, setShowPass] = useState(false);

  const roles = [
    { id: "owner", icon: "👑", title: "Owner", desc: "Sales, services & product management" },
    { id: "staff", icon: "✂️", title: "Staff", desc: "Billing, payments & appointments" },
    { id: "customer", icon: "💆", title: "Customer", desc: "Book appointments & view history" },
  ];

  const login = () => {
    const user = USERS[role];
    if (user && pass === user.password) {
      onLogin(role);
    } else {
      setError("Wrong password. Hint: owner123 / staff123 / cust123");
    }
  };

  return (
    <div style={S.loginWrap}>
      <div style={S.logoMark}>✂</div>
      <div style={S.brandName}>S4</div>
      <div style={S.brandSub}>SALON & SPA</div>

      <div style={S.roleCards}>
        {roles.map(r => (
          <div key={r.id} style={S.roleCard(role === r.id)} onClick={() => { setRole(r.id); setError(""); setPass(""); }}>
            <div style={S.roleIcon}>{r.icon}</div>
            <div>
              <div style={S.roleTitle}>{r.title}</div>
              <div style={S.roleDesc}>{r.desc}</div>
            </div>
            {role === r.id && <span style={{ marginLeft: "auto", color: "#c9a96e", fontSize: 18 }}>●</span>}
          </div>
        ))}
      </div>

      {role && (
        <div style={S.inputWrap}>
          <div style={{ position: "relative" }}>
            <input
              style={{ ...S.input, paddingRight: 44 }}
              type={showPass ? "text" : "password"}
              placeholder={`Password for ${role}…`}
              value={pass}
              onChange={e => { setPass(e.target.value); setError(""); }}
              onKeyDown={e => e.key === "Enter" && login()}
              autoFocus
            />
            <button
              onClick={() => setShowPass(v => !v)}
              style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-60%)", background: "none", border: "none", color: "#8a7a6a", cursor: "pointer", fontSize: 16 }}
            >
              {showPass ? "🙈" : "👁️"}
            </button>
          </div>
          {error && <div style={{ color: "#e07070", fontSize: 12, marginBottom: 8, paddingLeft: 4 }}>{error}</div>}
          <button style={S.loginBtn} onClick={login}>Sign In →</button>
        </div>
      )}

      {!role && (
        <div style={{ ...S.textMuted, marginTop: 24, fontSize: 12, textAlign: "center" }}>
          Select your role above to continue
        </div>
      )}
    </div>
  );
}

// ─── ROOT ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [user, setUser] = useState(null);

  return (
    <div style={S.app}>
      {!user ? (
        <LoginScreen onLogin={setUser} />
      ) : (
        <>
          {user === "owner" && <OwnerPortal />}
          {user === "staff" && <StaffPortal />}
          {user === "customer" && <CustomerPortal />}
          <button
            onClick={() => setUser(null)}
            style={{
              position: "fixed", top: 14, right: 14, zIndex: 300,
              background: "rgba(255,60,60,0.12)", border: "1px solid rgba(255,80,80,0.2)",
              color: "#e07070", borderRadius: 8, padding: "6px 12px",
              cursor: "pointer", fontSize: 12, fontFamily: "Georgia, serif",
            }}
          >
            🚪 Logout
          </button>
        </>
      )}
    </div>
  );
}
