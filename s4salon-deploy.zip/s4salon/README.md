# ✂ S4 Salon App — Deployment Guide

## How to deploy your app on Vercel (FREE)

---

### Step 1 — Create a GitHub account
1. Go to **github.com** and sign up (free)
2. Click **"New repository"**
3. Name it: `s4-salon`
4. Click **"Create repository"**

---

### Step 2 — Upload your files to GitHub
1. Click **"uploading an existing file"** link on GitHub
2. Drag and drop ALL the files from this ZIP folder
3. Keep the folder structure exactly as-is:
   ```
   s4-salon/
   ├── public/
   │   ├── index.html
   │   └── manifest.json
   ├── src/
   │   ├── App.js
   │   └── index.js
   ├── package.json
   └── vercel.json
   ```
4. Click **"Commit changes"**

---

### Step 3 — Deploy on Vercel
1. Go to **vercel.com** — sign up with your GitHub account
2. Click **"Add New Project"**
3. Select your `s4-salon` repository
4. Click **"Deploy"** (leave all settings as default)
5. Wait ~2 minutes — Vercel builds your app automatically!

---

### Step 4 — Get your live link
After deployment, Vercel gives you a URL like:
> **https://s4-salon.vercel.app**

Share this link with your staff and customers!

---

### Step 5 — Install on Android (Home Screen)
1. Open the link in **Chrome** on your Android phone
2. Tap the **3-dot menu** (top right corner)
3. Tap **"Add to Home screen"**
4. Name it **"S4 Salon"** → tap **Add**

The app now appears on your home screen like a real app! 📱

---

## Login Credentials

| Role     | Password   |
|----------|------------|
| 👑 Owner  | owner123   |
| ✂️ Staff  | staff123   |
| 💆 Customer | cust123  |

> **Important:** Change these passwords before going live. Edit the `USERS` object in `src/App.js`

---

## Need Help?
- Vercel docs: vercel.com/docs
- GitHub help: docs.github.com

Built with ❤️ for S4 Salon
